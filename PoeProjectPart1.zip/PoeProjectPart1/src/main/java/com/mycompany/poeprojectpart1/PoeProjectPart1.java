/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poeprojectpart1;
import java.util.Scanner;
/**
 *
 * @author apple
 */
public class PoeProjectPart1 {

    public static void main(String[] args) {
        Scanner myInput = new Scanner(System.in);  
        //Declaration of varibles
        String userName, passWord, cellPhone;
        //Promt the user
        System.out.println("Enter your Username ");
        userName = myInput.nextLine();
        
        System.out.println("Enter your Password ");
        passWord = myInput.nextLine();
        
        System.out.println("Enter your Cellphone ");
        cellPhone = myInput.nextLine();
        
        
        //Calling the REGISTER USER Method
    System.out.println(registerUser(userName, passWord, cellPhone));  
    //Calling the LOGIN USER Method
    System.out.println("\n===LOGIN===");
    
    //Caling the returnloginStatus
    boolean loginAccept = loginUser(userName, passWord);
    System.out.println(returnLoginStatus(loginAccept));
    
    if(loginUser(userName, passWord)){
        System.out.println("Welcome " + userName + ", it is great to see you again.");
    } else {
        System.out.println("Username or password incorrect, please try again.");
    }
    
    }
    
    //Method for checking username requirements
    public static boolean checkUsername(String userName) 
    {
        if(userName.contains("_") && userName.length() <= 5) {
            return true;
        } else {
            return false;
    }
    }
    //Method for checking password requirements
    public static boolean checkPasswordComplexity(String passWord) 
    { if(passWord.length() >= 8)
        return false;
    boolean hasCap = false;
    boolean hasDig = false;
    boolean hasSpec = false;
    //For Statement
        for(int  i=0;i<passWord.length();i++)
        { char c = passWord.charAt(i);
            if(Character.isUpperCase(c)) {
                hasCap = true;
            }
            else if(Character.isDigit(c)) {
                hasDig = true;
            }
            else if(!Character.isLetterOrDigit(c)) {
                hasSpec = true;
            }
        }  
        return hasCap && hasDig && hasSpec;
    }
    //Method for checking cell phone number requirements
    public static boolean checkCellPhoneNumber(String cellPhone)
    {
        if(!cellPhone.startsWith("+")) {
            return false;
        }
        String digits = cellPhone.substring(1);
        if(!digits.matches("\\d+")) {
            return false;
        }
        if(digits.length() < 10 || digits.length() >15)
            return false;
        return true;
    }
    //Method that returns registration messages
public static String registerUser(String userName, String passWord, String cellPhone) 
    {
    if(!checkUsername(userName))
    {
      return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length";         
    } 
    if(!checkPasswordComplexity(passWord))
    {
        return "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character ";
    }
    if(!checkCellPhoneNumber(cellPhone))
    {
        return "Cellphone number incorrectly formatted or does not contain international code ";
    } return "Username successfully captured.\n " + "Password successfully captured.\n " + "Cellphone successfully added.\n";
}
//Method that verifies if login detalis match the login details stored when registered
public static boolean loginUser(String userName, String passWord)
{
    Scanner myInput = new Scanner(System.in);
    //Declarations
    String usernameLogin;
    String passwordLogin;
    //Promt the user
    System.out.println("Enter your Username");
    usernameLogin = myInput.nextLine();
    
    System.out.println("Enter your Password");
    passwordLogin = myInput.nextLine();

    
    //Return Statement
return userName.equals(usernameLogin) && passWord.equals(passwordLogin); 

    
}
public static String returnLoginStatus(boolean loginAccept)
{
    if(loginAccept) {
        return "Login Successful.";
    } else {
        return"Login Failed";
    }
}
}


