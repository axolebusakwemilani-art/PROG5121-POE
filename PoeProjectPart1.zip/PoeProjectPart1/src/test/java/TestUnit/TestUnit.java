/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package TestUnit;

import static com.mycompany.poeprojectpart1.PoeProjectPart1.loginUser;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author apple
 */
public class TestUnit {
    
    public TestUnit() {
    }
    Login login = new Login();

//The username is correctly formatted
@Test
public void testCheckUsername_Valid() {
    assertEquals(true, login.checkUsername("kyl_1"));
}
//The username is incorrectly formatted
@Test
public void testCheckUsername_Invalid() {
    assertEquals(false, login.checkUsername("kyle!!!!!!"));
}
//The password meets the requirements
@Test
public void testPasswordComplexity_Valid() {
    assertEquals(true, login.checkPasswordComplexity("ch&&sec@ke99!"));
}
//the password does not meet the requirements
@Test
public void testPasswordComplexity_Invalid() {
    assertEquals(false, login.checkPasswordComplexity("password"));
}
//the cellphone number is correctly formatted
@Test
public void testCellPhoneNumber_Valid() {
     assertTrue(login.checkCellPhoneNumber("+27838968976"));
}
//the cellphone number is incorrectly formatted
@Test
public void testCellPhonrNumber_Invalid() {
    assertFalse(login.checkCellPhoneNumber("08966553"));
}

    private void assertTrue(Object checkCellPhoneNumber) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertFalse(Object checkCellPhoneNumber) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    //Successful login
    @Test
    public void testLoginAccept() {
        login.registerUser("kyl_1", "Pass@123");
        assertTrue(loginUser("kyl_1", "pass@123"));
    }
    //Failed login
    public void testLoginFailed() {
        login.registerUser("kyl_1, Pass@123");
        assertFalse(login.loginUser("kyl_1", "wrongPass"));
    }
}
